# Go To Line package

Move the cursor to a specific line in the editor using <kbd>ctrl-g</kbd>.

![](https://f.cloud.github.com/assets/671378/2241602/fdd88c4c-9cd8-11e3-9d14-74844ec7da01.png)
