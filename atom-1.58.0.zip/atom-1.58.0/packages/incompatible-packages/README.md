# Incompatible Packages package

Displays a list of installed Atom packages that have native module
dependencies that are not compatible with the current version of Atom.

![](https://cloud.githubusercontent.com/assets/671378/3767534/3f099820-18ce-11e4-9fa0-feef7947aab2.png)
