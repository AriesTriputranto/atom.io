'use babel';

module.exports = v => v + 1
