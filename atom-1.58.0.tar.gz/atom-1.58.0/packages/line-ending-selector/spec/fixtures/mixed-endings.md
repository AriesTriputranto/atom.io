Hello
Goodbye
Mixed
