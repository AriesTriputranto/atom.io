See https://flight-manual.atom.io/hacking-atom/sections/contributing-to-official-atom-packages/
